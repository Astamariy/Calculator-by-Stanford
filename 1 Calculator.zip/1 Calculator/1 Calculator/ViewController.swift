//
//  ViewController.swift
//  1 Calculator
//
//  Created by Александр Рузманов on 09.08.17.
//  Copyright © 2017 Александр Рузманов. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var userIsInTheMiddleOfTyping = false // It becomes true if user is typing number using keyboard.
    
    // Backspace button let users to touch if they hit the wrong digit button. This isn't "undo", so if the user hit the wrong operation button, he or she is out of luck. It uses .remove( at:) method to delete last digit.
    @IBAction func backspace(_ sender: UIButton) {
        if display.text != nil && userIsInTheMiddleOfTyping {
            var displayText = display.text!
            displayText.remove(at: displayText.index(before: displayText.endIndex))
            if displayText != "" {
                display.text = displayText
            } else { // If display.text == nil or user isn't in the middle of typing, it should get "0" value (as launch value of display.text).
                display.text = "0"
                userIsInTheMiddleOfTyping = false
            }
        } else {
            brain.undo()
            supportingDisplay.text = brain.evaluate(using: memory.container).description + (brain.evaluate(using: memory.container).isPending ? "..." : "=") // if result is pending, append "..." to the end of supporting display's text, otherwise append "=".
                displayValue = brain.evaluate(using: memory.container).result ?? 0.0
            userIsInTheMiddleOfTyping = false
        }
    }
    
    @IBOutlet weak var supportingDisplay: UILabel! // That's small display on the top of the screen. It's used to show the sequence of operands and operations.
    
    @IBOutlet weak var display: UILabel! // That's major display.
    
    // Function for interpretate touch digit action performed by user. If user is in the middle of typing it appends digit to the currrent major display's value. Otherwise it assigns digit to the major display's value.
    @IBAction func touchDigit(_ sender: UIButton) {
        let digit = sender.currentTitle!
        if userIsInTheMiddleOfTyping && !display.text!.contains("M") {
            let textCurrentlyInDisplay = display.text!
            display.text = textCurrentlyInDisplay + digit
        } else {
            display.text = digit
            userIsInTheMiddleOfTyping = true
        }
    }
    
    // It converts major display's value to Double, when it get value, and set major display's value to String value of themselve, when set it's value.
    var displayValue: Double {
        get {
            if let value = Double(display.text!) {
                return value
            } else {
                return 0.0
            }
        }
        set {
            // NumberFormatter class provide opportunity to declare minimum and maximum sugnificant digits after point.
            let formatter = NumberFormatter()
            formatter.usesSignificantDigits = true
            formatter.minimumSignificantDigits = 0
            formatter.maximumSignificantDigits = 6
            display.text = formatter.string(from: newValue as NSNumber)
        }
    }
    
    // Copy CalculatorBrain (Model) to the ViewController (Controller). See MVC conception.
    private var brain: CalculatorBrain = CalculatorBrain()
    
    // Function was designed to perform operations (when user touch operation button) by using CalculatorBrain public methods.
    @IBAction func performOperation(_ sender: UIButton) {
        if sender.currentTitle == "C" {
            memory.container = nil
        }
        if userIsInTheMiddleOfTyping {
            brain.setOperand(variable: display.text!)
            userIsInTheMiddleOfTyping = false
        }
        userIsInTheMiddleOfTyping = false
        if let mathematicalSymbol = sender.currentTitle {
            brain.performOperation(mathematicalSymbol)
            supportingDisplay.text = brain.evaluate(using: memory.container).description + (brain.evaluate(using: memory.container).isPending ? "..." : "=") // if result is pending, append "..." to the end of supporting display's text, otherwise append "=".
        }
        if let result = brain.evaluate(using: memory.container).result {
            displayValue = result
        }
        // If operation is "C" or reset, return interface in the same state it was in when user launched it.
        if sender.currentTitle == "C" {
            display.text = "0"
            supportingDisplay.text = " "
        }
    }
    
    
    // Function was designed to allow legal floting point numbers to be entered (192.168.0.1 is not legal).
    @IBAction func touchDot(_ sender: UIButton) {
        if !display.text!.contains(sender.currentTitle!) && userIsInTheMiddleOfTyping && !display.text!.contains("M") { // if there is not dot at the display's text and user is in the middle of typing, add dot (.)
            let textCurrentlyInDisplay = display.text!
            display.text = textCurrentlyInDisplay + sender.currentTitle!
        }
    }
    
    
    
    // Initialize memory model to using it in controller class when it did set memory display also changed
    private var memory = memoryModel() {
        didSet {
            if memory.container != nil {
                if let value = memory.container!["M"] {
                    memoryDisplay.text = "Memory contains value: \(value)"
                }
            } else {
                memoryDisplay.text = "Memory is empty"
            }
        }
    }
    
    
    // Method used to set or clean memory values.
    @IBAction func setMemory(_ sender: UIButton) {
        if memory.isUsing {
            memory.container = nil
        } else {
            if let value = Double(display.text!) {
                memory.container = [
                    "M" : value
                ]
            }
        }
        if let result = brain.evaluate(using: memory.container).result {
            displayValue = result
        }
        userIsInTheMiddleOfTyping = false
    }
    
    // Method used to get variable "M" as operand.
    @IBAction func getMemoryValue(_ sender: UIButton) {
        display.text! = "M"
        userIsInTheMiddleOfTyping = true
    }
    
    // Display used to indicate is memory used or not and if it is to also display value in memory.
    @IBOutlet weak var memoryDisplay: UILabel!
    
    
}


