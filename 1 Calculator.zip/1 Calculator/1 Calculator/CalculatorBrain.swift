//
//  CalculatorBrain.swift
//  1 Calculator
//
//  Created by Александр Рузманов on 09.09.17.
//  Copyright © 2017 Александр Рузманов. All rights reserved.
//

import Foundation

struct CalculatorBrain {
    
    // PROGRAMMING PROJECT 2
    
    // Especial method to cancel previous operation.
    mutating func undo() {
        if operationsSequence.count > 0 {
            operationsSequence.removeLast()
        }
    }
    
    // Indicates that operand (variable) was set by binary operation performing
    private var operandWasSetByPerformingBinaryOperation = false
    
    // Array of tuples containing accumulator (entered by user value) values and symbol, that is operation button's title was pressed.
    private var operationsSequence = [(accumulator: String?, symbol: String)]()
    
    // Method to set variable value.
    mutating func setOperand(variable named: String) {
        variable = named
        operandWasSetByPerformingBinaryOperation = false
    }
    
    // Contains operand value
    private var variable: String?
    
    // The main method of calculator brain struct. Perform operations in operations sequence and return result, resultIsPending and description values. Used variables dictionary, that contains values of variables (like "M").
    func evaluate(using variables: Dictionary<String, Double>? = nil) -> (result: Double?, isPending: Bool, description: String) {
        
        // variable used to contain operand or result of performed operation
        var accumulator: Double?
        
        // Variable used to get result to display its value on the main screen of calculator.
        var result: Double? {
            return accumulator
        }
        
        
        // PERFORM OPERATION METHOD'S CONTENT
        
        //
        // Binary operation's content
        //
        
        
        // Indicate that current accumulator was set by performing binary operation
        var operandWasSetByPerformingBinaryOperation = false
        
        // The struct includes "function" constant using to store binary operation function value, "firstOperand" constant using to store operand value, and "perform" function using to perform binary operation with second operand value.
        struct PendingBinaryOperation {
            var function: (Double, Double) -> Double
            let firstOperand: Double
            func perform(with secondOperand: Double) -> Double {
                return function(firstOperand, secondOperand)
            }
        }
        
        // The variable using to initialize PendingBinaryOperation struct.
        var pendingBinaryOperation: PendingBinaryOperation?
        
        // Variable used to indicate is result pending by performing binary operation right now!
        var resultIsPending: Bool {
            get {
                if pendingBinaryOperation != nil {
                    return true
                } else {
                    return false
                }
            }
        }
        
        // The function allows to perform pending binary operation by using "perform(with: Double)" method of PendingBinaryOperation struct.
        func performPendingBinaryOperation() {
            if resultIsPending && accumulator != nil && operandWasSetByPerformingBinaryOperation == false {
                accumulator = pendingBinaryOperation!.perform(with: accumulator!)
                pendingBinaryOperation = nil
                operandWasSetByPerformingBinaryOperation = true
            }
        }
        
        
        
        //
        // Random operation's content
        //
        
        // The fuction generate a random double-precision floating point number by using arc4random_uniform method.
        func generateARandomDoublePrecisionFloatingPointNumber() {
            accumulator = Double(arc4random_uniform(101)) / 100
            operandWasSetByPerformingBinaryOperation = false
        }
    
        //
        // Generate description operation
        //
        
        // Variable used to store the character of a constant.
        var constantSymbol: String?
        
        // Used to store previous step description value.
        var previousDescription: String?
        
        // Contains previous operation operator symbol
        var previousOperationKind: Operation?
        
        // The function implements the choice between the constant symbol and the value of the operand. If operand is constant then should use constant symbol (π, e etc.) instead it's value (operand).
        func chosenValue() -> String {
            if let temporaryConstantSymbol = constantSymbol {
                constantSymbol = nil
                return temporaryConstantSymbol
            } else {
                if accumulator != nil {
                    // NumberFormatter class provide opportunity to declare minimum and maximum sugnificant digits after point
                    let formatter = NumberFormatter()
                    formatter.usesSignificantDigits = true
                    formatter.minimumSignificantDigits = 0
                    formatter.maximumSignificantDigits = 6
                    return formatter.string(from: accumulator! as NSNumber)!
                }
            }
            return ""
        }
        
        // Variable used to store description of all actions which have been performed. Its value used to be shown on the supporting display.
        var description: String = "" {
            didSet {
                previousDescription = oldValue
            }
        }
        
        // Method used to make and set the value to the description variable
        func generateDescription(_ symbol: String) {
            if let operation = operations[symbol] {
                switch operation {
                case .constant:
                    constantSymbol = symbol
                    switch previousOperationKind {
                    case .constant?, .unaryOperation?, .equals?, .random?:
                        description = resultIsPending ? (previousDescription ?? "") : ""
                        description += chosenValue()
                    default:
                        description += chosenValue()
                    }
                    
                case .unaryOperation:
                    switch previousOperationKind {
                    case .unaryOperation?:
                        if previousDescription != nil && resultIsPending {
                            let index = previousDescription!.endIndex
                            let addedPartOfTheDescriptionByPreviousStep = String(description.suffix(from: index))
                            description = previousDescription!
                            description += symbol + "(" + addedPartOfTheDescriptionByPreviousStep + ")"
                        } else {
                            description = symbol + "(" + description + ")"
                        }
                    case .equals? :
                        description = symbol + "(" + description + ")"
                    case .constant?, .random? :
                        constantSymbol = String(description.suffix(from: previousDescription?.endIndex ?? "".endIndex))
                        description = previousDescription ?? ""
                        description += symbol + "(" + chosenValue() + ")"
                    default:
                        description += symbol + "(" + chosenValue() + ")"
                    }
                    
                case .binaryOperation:
                    if accumulator != nil {
                        switch previousOperationKind {
                        case .binaryOperation?, nil:
                            if operandWasSetByPerformingBinaryOperation == false {
                                description += chosenValue() + symbol
                            } else {
                                description.removeLast()
                                description += symbol
                            }
                        case .equals?:
                            if operandWasSetByPerformingBinaryOperation == false {
                                description = chosenValue() + symbol
                            } else {
                                description = "(" + description + ")" + symbol
                            }
                        case .unaryOperation?:
                            description = description + symbol
                        default:
                            description += symbol
                        }
                        
                    } else {
                        switch previousOperationKind {
                        case .binaryOperation?:
                            description.removeLast()
                            description += symbol
                        default:
                            break
                        }
                    }
                    
                    
                case .equals:
                    if resultIsPending && accumulator != nil {
                        switch previousOperationKind {
                        case .binaryOperation?, .equals?:
                            description += chosenValue()
                        default:
                            break
                        }
                    }
                    
                case .random:
                    constantSymbol = symbol
                    switch previousOperationKind {
                    case .constant?, .unaryOperation?, .equals?, .random?:
                        description = resultIsPending ? (previousDescription ?? "") : ""
                        description += chosenValue()
                    default:
                        description += chosenValue()
                    }
                    
                default:
                    break
                }
            }
        }
        
        //
        // Reset operation's content
        //
        
        // The function reset all to initial values.
        func reset() {
            pendingBinaryOperation = nil
            accumulator = 0
            description = ""
            operandWasSetByPerformingBinaryOperation = false
            previousOperationKind = nil
        }
        
        
        //Method used to perform operation.
        func performOperation(_ symbol: String?) {
            if symbol != nil {
                // Call method used to set description variable value.
                generateDescription(symbol!)
                if let operation = operations[symbol!] { // Сheck for the presence of a symbol in the operations dictionary.
                    switch operation {
                    case .constant(let associatedConstantValue): // Create new Double associatedConstantValue.
                        // ----------------------------------The major action is calculation constant value.----------------------------------
                        accumulator = associatedConstantValue
                        operandWasSetByPerformingBinaryOperation = false
                        
                    case .unaryOperation(let function): // Create new function ((Double) -> Double) type value.
                        if  accumulator != nil {
                            // -------------------------------Perform major task, which is calculation of unary function result.----------------------------------
                            accumulator = function(accumulator!)
                            operandWasSetByPerformingBinaryOperation = false
                        }
                    case .binaryOperation(let function): // Create new function ((Double, Double) -> Double) type value.
                        if accumulator != nil {
                            if resultIsPending {
                                // ---------------------------This is major calculation of the result of Binary Operation.----------------------------------
                                if operandWasSetByPerformingBinaryOperation == false {
                                    performPendingBinaryOperation()
                                    pendingBinaryOperation = PendingBinaryOperation(function: function, firstOperand: accumulator!)
                                } else {
                                    pendingBinaryOperation?.function = function
                                }
                            } else {
                                // ----------------Initialize PendingBinaryOperation struct with function and first operand value.----------------------------------
                                pendingBinaryOperation = PendingBinaryOperation(function: function, firstOperand: accumulator!)
                                accumulator = nil
                            }
                        } else {
                            if resultIsPending {
                                pendingBinaryOperation?.function = function
                            }
                        }
                    case .equals:
                        performPendingBinaryOperation()
                    case .reset:
                        reset()
                    case .random:
                        generateARandomDoublePrecisionFloatingPointNumber()
                    default:
                        break
                    }
                }
            }
        }
        
        // set accumulator value and perform operation for each operation in operations sequence using variables dictionary to interpret variable meaning (value)
        if operationsSequence.count > 0 {
            for operation in operationsSequence {
                if let variable = operation.accumulator {
                    if let operand = Double(variable) {
                        accumulator = operand
                        operandWasSetByPerformingBinaryOperation = false
                    } else {
                        constantSymbol = variable
                        accumulator = variables?[variable] ?? 0.0
                        operandWasSetByPerformingBinaryOperation = false
                    }
                }
                performOperation(operation.symbol)
                previousOperationKind = operations[operation.symbol]
            }
        }
        
        
        
        
        return (result, resultIsPending, description)
    }
    
    
    //STORAGE DECLARING
    
    // This is a special list, in which the type of operation corresponds to the type of function that it assumed.
    private enum Operation {
        case constant(Double)
        case unaryOperation((Double) -> Double)
        case binaryOperation((Double, Double) -> Double)
        case equals
        case reset
        case random
        case variable
    }
    
    // This is a dictionary that contains a function definition (according to the type from Operation list) for each calculator keyboard symbol's value.
    private var operations: Dictionary<String,Operation> = [
        "π" : Operation.constant(Double.pi), // Double.pi
        "e" : Operation.constant(M_E), // M_E = exp
        "ln" : Operation.unaryOperation(log), // ln
        "√" : Operation.unaryOperation(sqrt), // sqrt
        "cos" : Operation.unaryOperation(cos), // cos
        "sin" : Operation.unaryOperation(sin), // sin
        "±" : Operation.unaryOperation({-$0}), // change sign
        "R" : Operation.random, // random double-precision floating point number
        "×" : Operation.binaryOperation({$0*$1}), // multiply
        "÷" : Operation.binaryOperation({$0/$1}), // divide
        "+" : Operation.binaryOperation({$0+$1}), // add
        "-" : Operation.binaryOperation({$0-$1}), // deduct
        "=" : Operation.equals, // equals
        "C" : Operation.reset, // reset
        "y" : Operation.variable
    ]
    
    
    // PUBLIC API
    
    
    // Variable used to get result to display its value on the main screen of calculator.
    var result: Double? {
        get {
            return evaluate().result
        }
    }
    
    // Variable used to store description of all actions which have been performed. Its value used to be shown on the supporting display.
    var description: String {
        get {
            return evaluate().description
        }
    }
    
    // Variable used to indicate is result pending by performing binary operation right now!
    var resultIsPending: Bool {
        return evaluate().isPending
    }
    
    // Method that is called when operation's button was pressed by user. It just only set operation sequence by append, remove or change some values of this array.
    mutating func performOperation(_ symbol: String) {
        if let operation = operations[symbol] {
            switch operation {
            case .binaryOperation:
                    if operandWasSetByPerformingBinaryOperation && evaluate().isPending {
                        let previousOperation = operationsSequence.removeLast()
                        operationsSequence.append((previousOperation.accumulator, symbol))
                    } else {
                        operationsSequence.append((variable, symbol))
                    }
                operandWasSetByPerformingBinaryOperation = true
            case .reset:
                operationsSequence.removeAll()
                operandWasSetByPerformingBinaryOperation = false
            default:
                operationsSequence.append((variable, symbol))
                operandWasSetByPerformingBinaryOperation = false
            }
        }
        variable = nil
    }
    

    

}

