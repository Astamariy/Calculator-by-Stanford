//
//  MemoryModel.swift
//  1 Calculator
//
//  Created by Александр Рузманов on 10.10.2017.
//  Copyright © 2017 Александр Рузманов. All rights reserved.
//

import Foundation

// The struct used to provide dictionary with memory value and especial variable to indicate, that memory model struct is used.
struct memoryModel {
    var container: Dictionary<String, Double>?
    var isUsing: Bool  {
        get {
            return ((container != nil) ? true : false)
        }
    }
}
